# job4j_design
Проект содержит решения блока "Junior" курса Job4j.

В этом проекте рассмотрены:
- Структуры данных и алгоритмы, Maven
- Ввод-вывод
- SQL, JDBC
- Garbage Collection
- ООД